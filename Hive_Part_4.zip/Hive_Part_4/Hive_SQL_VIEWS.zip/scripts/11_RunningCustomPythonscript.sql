
add file '/Users/swethakolalapudi/function.py'

SELECT TRANSFORM(firstname,lastname) USING 'python function.py' from employees; 