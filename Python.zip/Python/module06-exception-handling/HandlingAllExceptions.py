if __name__ == '__main__':
    try:
        numerator = int(input("Enter numerator"))
        denominator = int(input("Enter denominator"))
        result = numerator/denominator
        print("Result= ",result)
    except:
        print("Oops! unable to calculate")