data["maps"][0]["id"]
data["masks"]["id"]
data["om_points"]