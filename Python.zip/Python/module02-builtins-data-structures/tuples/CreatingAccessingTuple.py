if __name__ == '__main__':
    # Creating Tuple
    tuple_one = (1,2,3,4,5)
    # Elements of tuples cannot be modified
    #tuple_one[1]=11
    print(tuple_one)

    # Iterating tuple
    for elmnt in tuple_one:
        print(elmnt)