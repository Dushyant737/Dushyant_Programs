if __name__ == '__main__':
    tuple_elments = (1,2,3,4)
    print(2 in tuple_elments)
    print(22 not in tuple_elments)