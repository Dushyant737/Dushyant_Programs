if __name__ == '__main__':
    set_one = set([1,2,3,4])
    print(set_one)

    set_two = {5,6,7}
    print(set_two)