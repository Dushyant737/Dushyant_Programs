if __name__ == '__main__':
    # Creating List
    number_list = [1,2,3,4,5]

    # Creating List
    programming_languages = ["C","C++","Java"]

    # Accessing List
    print(number_list[2])

    # Iterating List
    for n in number_list:
        print("Element",n)

    # Couting List elements
    print("Total number of list",len(number_list))