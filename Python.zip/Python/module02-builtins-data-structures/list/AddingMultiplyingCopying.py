if __name__ == '__main__':
    list_one = [1,3]
    list_two = [2,4]

    # Adding Lists
    print(list_one+list_two)
    list_one+=list_two
    print(list_one)

    # Multiplying Lists
    list_result = list_one*2
    print(list_result)