if __name__ == '__main__':
    dictionary_elements = {"apple":"red","grapes":"green"}
    print("apple" in dictionary_elements)