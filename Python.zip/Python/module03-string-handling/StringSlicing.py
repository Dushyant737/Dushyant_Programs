if __name__ == '__main__':
    str = "Well come to NPN Training"

    print(str[0])
    print(str[0:3])
    print(str[0:])
    print(str[:10])
    print(str[0:len(str)])
    print(str[-1])
    print(str[0:len(str):2]);

    # Reversing a string
    print(str[::-1])