if __name__ == '__main__':
    str = "Uncle Sam"
    #str[0]= "L"
    print(str)

    new_str = "Hello"+" "+str[::-1]
    print(new_str)

    s1 = "npn training - Naveen"
    print(s1.upper())
    print(s1.capitalize())
    print(s1.swapcase())
    print(s1.expandtabs(3))