if __name__ == '__main__':
    str_one = "Well come to learn Python"
    str_two = 'Well come to learn Python'
    str_three = "Well come to learn 'python'"
    print("{}\n{}-\n{}".format(str_one,str_two,str_three))