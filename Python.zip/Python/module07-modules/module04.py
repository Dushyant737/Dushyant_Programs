def m4_fn1():
    print("Module 04 - fn1")


def m4_fn2():
    print("Module 04 - fn1")