from com.npntraining import module02 as m2, module03 as m3
import com.module01 as m1

if __name__ == '__main__':
    m2.m2_fn1()
    m1.m1_fn1()