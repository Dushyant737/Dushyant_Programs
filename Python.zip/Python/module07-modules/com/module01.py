def m1_fn1():
    print("Module 01 - fn1")


def m1_fn2():
    print("Module 01 - fn1")