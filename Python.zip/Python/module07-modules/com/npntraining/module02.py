def m2_fn1():
    print("Module 02 - fn1")


def m2_fn2():
    print("Module 02 - fn1")