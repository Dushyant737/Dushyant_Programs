def m3_fn1():
    print("Module 03 - fn1")


def m3_fn2():
    print("Module 03 - fn1")