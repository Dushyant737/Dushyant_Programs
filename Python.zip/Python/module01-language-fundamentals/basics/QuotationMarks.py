if __name__ == '__main__':
    print('"Hello World"')
    print("'Hello World'")
    print("""
    Allows lines to span multiple lines
    This is line 01
    This is line 02
    """)