if __name__ == '__main__':
    i = 2
    print(type(i))

    print(isinstance(i,int))


    print("Hell","World","in","Python",sep="|")
