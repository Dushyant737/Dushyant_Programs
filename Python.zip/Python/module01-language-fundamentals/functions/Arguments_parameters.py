def sum(x,y):
    print(x+y)
sum(2,3)