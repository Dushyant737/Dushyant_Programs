def f(a,b,c=2,d=3):
    print(a,b,c,d)

f(10,20,30)
f(10,20,d=30)