def calc(x,y):
    l=[x+y,x-y,x*y,x/y]
    return l

result=calc(2,3)
print(result)