x = int(input("Enter an integer"))
if x > 0:
    print("{} is positive".format(x))
elif x < 0:
    print ("{} is negative".format (x))
else:
    print ("{} is zero".format (x))