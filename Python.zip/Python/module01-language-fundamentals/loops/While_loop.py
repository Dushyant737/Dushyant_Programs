n = int(input("ENter a positive integer"))
i = 1
while i <= n:
    print(i)
    i=i+1
