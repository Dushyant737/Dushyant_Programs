create table Students
(StudentID INT,
firstname VARCHAR(50),
LastName VARCHAR(50),
Gender Char(1),
Email VARCHAR(100));


INSERT INTO Students
VALUES
(1,'Janani','Ravi','F','Janani@loonycorn.com'),
(2,'Swetha','Kollalapudi','F','Swetha@loonycorn'),
(3,'Navdeep','Singh','M','navdeep@loonycorn.com'),
(4,'Vitthal','Srinivasan','M','vitthal@loonycorn.com');